<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />

<link href="assets/fonts/FreigSanPro/font.min.css" rel="stylesheet" type="text/css">


<link rel="stylesheet" type="text/css" href="assets/css/kalifika.min.css">
<link rel="icon" type="image/x-icon" href="favicon.ico" />
