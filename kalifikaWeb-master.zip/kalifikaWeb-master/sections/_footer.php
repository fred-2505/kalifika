<footer class="kfk-footer" style="background-color: #5B5F66; margin-top: auto; color:#FFF">
        <div class="container" style="margin-bottom: auto">
            <div class="kfk-footer-copyright">
                <p>
                    Copyright © 2016 FIT For Innovation Technology. Todos los derechos reservados.
                </p>
            </div>
            <div class="kfk-brands">
                <ul class="brands brands-inline brands-sm brands-transition brands-circle">
                    <li>
                        <a class="brands-facebook" href="#">
                            <i class="fa fa-facebook">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-twitter" href="#">
                            <i class="fa fa-twitter">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-google-plus" href="#">
                            <i class="fa fa-google-plus">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-linkedin" href="#">
                            <i class="fa fa-linkedin">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-youtube" href="#">
                            <i class="fa fa-youtube">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-skype" href="#">
                            <i class="fa fa-skype">
                            </i>
                        </a>
                    </li>
                </ul>
            </div>
    </div>
</footer>
