<div id="kfk-dialog-tutorial" class="dialog kfk-dialog">
    <div class="dialog__overlay dialog__black"></div>
    <div class="dialog__content dialog__content__large padding-0">
        <div class="dialog__close " data-embed="kfk-embed-tutorial" data-dialog-close><span aria-hidden="true"><i class="fa fa-times"></i></span></div>
        <div class="kfk-embed-container" id="kfk-embed-tutorial">
            <iframe class="kfk-dialog-video" width="560" height="315" src="https://www.youtube.com/embed/RF0HhrwIwp0?rel=0" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
</div>