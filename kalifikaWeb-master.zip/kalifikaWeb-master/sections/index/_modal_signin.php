<div id="kfk-dialog-signin" class="dialog kfk-dialog" style="z-index:9999">
    <div class="dialog__overlay"></div>
    <div class="dialog__content dialog__content__small">
        <div style="position: absolute; top: 2em; right: 2em">
            <button type="button" class="close action" data-dialog-close><span aria-hidden="true">&times;</span></button>
        </div>
        <div class="text-center">
            <img src="assets/images/logo.png" data-src="assets/images/logo.png" data-src-retina="assets/images/logo.png" />
        </div>
        <br>
        <form class="" id="kfk-form1" role="form" action="" method="post">
            <div class="form-group">
                <input type="text" class="form-control text-center" placeholder="Ingrese su DNI">
            </div>
            <div class="form-group">
                <input type="text" class="form-control text-center" placeholder="Ingrese su password">
            </div>
            <div class="checkbox text-left">
                    <input type="checkbox" id="kfk-checkbox1" />
                <label for="kfk-checkbox1">
                    Recordar mi correo
                </label>
            </div>
            <a type="submit" href="dashboard.php" class="btn btn-primary btn-block text-center">Ingresar</a>
            <hr/>
            <div>¿No tienes una cuenta?</div>
            <a href="signup.php" class="link">Regístrate ahora, es gratis</a>
            <hr/>
            <div>¿Tienes problemas para ingresar?</div>
            <a class="page-scroll" href="#kfk-section-contactos" data-dialog-close>Contáctenos aquí</a>
        </form>
    </div>
</div>
