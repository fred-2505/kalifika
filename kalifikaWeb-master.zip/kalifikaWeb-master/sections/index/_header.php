<nav class="navbar navbar-default navbar-fixed-top top-nav-collapse">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header page-scroll">
            <button aria-expanded="false" class="navbar-toggle collapsed" data-target="#kfk-menu" data-toggle="collapse" type="button">
                <span class="sr-only">
                    Toggle navigation
                </span>
                <span class="icon-bar">
                </span>
                <span class="icon-bar">
                </span>
                <span class="icon-bar">
                </span>
            </button>
            <a class="navbar-brand" href="#kfk-section-home">
                <img alt="Logo" src="assets/images/logo.png" width="90">
                </img>
            </a>
            <div class="visible-xs">
                <button class="btn btn-primary navbar-btn m-r-5 pull-right kfk-login-bootbox" type="button">
                    Inicio Sesión
                </button>
            </div>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="kfk-menu">
            <?php require_once './sections/index/_menu.php';?>
            <div class="hidden-xs">
                <a class="btn btn-primary navbar-btn m-r-5 pull-right" href="signup.php" type="button">
                    Regístrate
                </a>
                <button class="btn btn-primary navbar-btn m-r-5 pull-right kfk-login-bootbox" type="button">
                    Inicio Sesión
                </button>
            </div>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
</nav>