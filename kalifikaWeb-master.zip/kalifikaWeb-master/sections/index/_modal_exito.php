<div id="kfk-dialog-exito" class="dialog kfk-dialog" style="z-index:9999">
    <div class="dialog__overlay"></div>
    <div class="dialog__content dialog__content__small">
        <div style="position: absolute; top: 0em; right: 1em">
            <button type="button" class="close action" data-dialog-close><span aria-hidden="true">&times;</span></button>
        </div>
        <p><br/><br/>Tu solicitud de subasta ha sido enviada correctamente. <br> La entidad financiera pronto se pondrá en contacto contigo.<br/><br/></p>
        <br>
    </div>
</div>
