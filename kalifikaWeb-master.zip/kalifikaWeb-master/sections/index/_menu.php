<ul class="nav navbar-nav">
    <li class="active home"><a class="page-scroll" href="#kfk-section-home">Home</a></li>
    <li><a class="page-scroll" href="#kfk-section-beneficios">Beneficios</a></li>
    <li><a class="page-scroll" href="#kfk-section-score">Score</a></li>
    <li><a class="page-scroll" href="#kfk-section-pasos">Pasos</a></li>
    <li><a class="page-scroll" href="#kfk-section-contactos">Contactos</a></li>
</ul>