<ul class="nav navbar-nav">
    <li><a class="page-scroll" href="index.php#kfk-section-home">Home</a></li>
    <li><a class="page-scroll" href="index.php#kfk-section-beneficios">Beneficios</a></li>
    <li><a class="page-scroll" href="index.php#kfk-section-score">Score</a></li>
    <li><a class="page-scroll" href="index.php#kfk-section-pasos">Pasos</a></li>
    <li><a class="page-scroll" href="index.php#kfk-section-contactos">Contactos</a></li>
</ul>