<footer class="kfk-footer kfk-footer-user clearfix">
    <div class="row-fluid">
        <div class="container">
            <a class="complains" href="reclamo.php">
                <img height="20px" src="assets/images/reclamaciones.png"/>
                <span class="text-muted">
                    Libro de Reclamaciones
                </span>
            </a>
            <a class="btn btn-primary pull-right" href="signin.php">
                <i class="fa fa-power-off">
                </i>
                Cerrar sesión
            </a>
        </div>
    </div>
    <div class="kfk-container  kfk-footer-user">
        <div class="container">
            <div class="kfk-footer-copyright">
                <p>
                    Copyright © 2016 FIT For Innovation Technology. Todos los derechos reservados.
                </p>
            </div>
            <div class="kfk-brands">
                <ul class="brands brands-inline brands-sm brands-transition brands-circle">
                    <li>
                        <a class="brands-facebook" href="reclamo.php">
                            <img src="assets/images/reclamaciones.png" width="30px"/>
                        </a>
                    </li>
                    <li>
                        <a class="brands-facebook" href="#">
                            <i class="fa fa-facebook">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-twitter" href="#">
                            <i class="fa fa-twitter">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-google-plus" href="#">
                            <i class="fa fa-google-plus">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-linkedin" href="#">
                            <i class="fa fa-linkedin">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-youtube" href="#">
                            <i class="fa fa-youtube">
                            </i>
                        </a>
                    </li>
                    <li>
                        <a class="brands-skype" href="#">
                            <i class="fa fa-skype">
                            </i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
