<div class="dialog kfk-dialog m-t-50" id="kfk-dialog-detalle">
    <div class="dialog__content">
        <div style="position: absolute; top: 2em; right: 2em">
            <button class="close action close-deuda" type="button">
                <span aria-hidden="true">
                    <small>
                        volver
                        <i class="fa fa-arrow-right">
                        </i>
                    </small>
                </span>
            </button>
        </div>
        <h3 class="text-primary">
            Historial
        </h3>
        <div class="row">
            <div class="col-xs-12 col-sm-6">
                <div id="chartdiv1" style="width:100%; height:300px;">
                </div>
            </div>
            <div class="col-xs-12 col-sm-6">
                <div id="chartdiv2" style="width:100%; height:300px;">
                </div>
            </div>
        </div>
        <div class="text-center m-t-20">
            <img data-src="assets/images/logo.png" data-src-retina="assets/images/logo.png" height="20" src="assets/images/logo.png"/>
        </div>
    </div>
</div>

