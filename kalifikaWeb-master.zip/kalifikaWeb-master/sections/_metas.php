<meta name="robots" content="index,follow,archive">
<meta name="googlebot" content="index,follow,archive">

<meta property="og:url" content="http://kalifika.com/" />
<meta property="og:type" content="website" />
<meta property="og:title" content="kalifica" />
<meta property="og:description" content="descripción" name="description" />
<meta property="og:site_name" content="kalifika">
<meta property="og:image" content="assets/images/logo.png" />

<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@kalifica">
<meta name="twitter:creator" content="@kalifica">
<meta name="twitter:title" content="kalifica">
<meta name="twitter:description" content="descripción">
<meta name="twitter:image" content="assets/images/logo.png">
<meta name="twitter:url" content="http://kalifika.com/">


<link rel="apple-touch-icon" href="assets/ico/60.png">
<link rel="apple-touch-icon" sizes="76x76" href="assets/ico/76.png">
<link rel="apple-touch-icon" sizes="120x120" href="assets/ico/120.png">
<link rel="apple-touch-icon" sizes="152x152" href="assets/ico/152.png">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">

<meta content="descripción" />
<meta content="kalifica" name="author" />