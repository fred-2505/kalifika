<script type="text/javascript" src="assets/js/kfk-preloader.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="assets/plugins/modernizr.custom.js"></script>
<script type="text/javascript" src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<script type="text/javascript" src="assets/plugins/jquery/jquery-easy.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-unveil/jquery.unveil.min.js"></script>


<script type="text/javascript" src="assets/plugins/bootbox/bootbox.min.js"></script>

<!-- Scrolling Nav JavaScript -->
<script src="assets/plugins/scrolling-nav/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scrolling-nav/js/scrolling-nav.js"></script>

<script type="text/javascript" src="assets/js/kalifica.min.js"></script>