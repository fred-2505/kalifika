var kfk = kfk || {};
kfk.signUp = (function($) {
    'use strict';
    var $_nextTab = function(elem) {
        $(elem).next().find('a[data-toggle="tab"]').click();
    };
    var $_prevTab = function(elem) {
        $(elem).prev().find('a[data-toggle="tab"]').click();
    };
    var $_tooltip = function() {
        $(".dni-validator").focus(function() {
            $(".kfk-tooltip").addClass("active");
        }).on("blur", function() {
            $(".kfk-tooltip").removeClass("active");
        });
    };
    var $_build = function() {
        $_tooltip();
        $('.nav-tabs > li a[title]').tooltip();
        //Wizard
        $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
            var $target = $(e.target);
            if ($target.parent().hasClass('disabled')) {
                return false;
            }
        });
        $(".next-step").click(function(e) {
            var $active = $('.wizard .nav-tabs li.active');
            $active.next().removeClass('disabled');
            $_nextTab($active);
        });
        $(".prev-step").click(function(e) {
            var $active = $('.wizard .nav-tabs li.active');
            $_prevTab($active);
        });
        $('#kfk-checkbox1').on('click', function() {
            if ($(this).is(':checked')) {
               bootbox.alert({
                'title':'<h3 class="text-primary">Políticas de privacidad y términos y condiciones</h3>',
                'message': '<div class="scrollbar-macosx full-width" style="max-height: 200px;overflow-y: scroll; border:1px solid #ccc; padding: 10px; border-radius: 5px; margin-bottom: 15px; color:#7e7e7e">Lorem ipsum dolor sit amet, cu mnesarchum efficiantur vix, prodesset instructior te sea. No oratio accusata nam, cu magna alterum verterem his, quo te forensibus consetetur. Mei volutpat mediocritatem no, et paulo exerci splendide vel. His vero instructior ad, nam ex maiorum imperdiet.Prima antiopam molestiae ei his. Ea munere offendit sed, duo in novum appareat, praesent incorrupte eum ei. Ex homero pertinax has. Suas fierent scriptorem cu per. Qualisque delicatissimi ut mel.Vim te affert omittam reformidans, no habemus disputationi mei, ex sit probatus definitionem. Sed ex legimus definiebas. At graece oporteat instructior mei, wisi dolorem verterem cu vix, audire blandit persequeris vis te. Cibo insolens ad vel. Vis ei accusam tincidunt disputando.Solet omnesque omittantur per te. Quis nihil oblique ne est. Meis iudico vivendo ne ius, ex eam iracundia voluptaria. Sed at intellegam consectetuer, velit utinam deterruisset ut quo. Eu ceteros copiosae sed, cum an accusata efficiantur reprehendunt.Prima antiopam molestiae ei his. Ea munere offendit sed, duo in novum appareat, praesent incorrupte eum ei. Ex homero pertinax has. Suas fierent scriptorem cu per. Qualisque delicatissimi ut mel.Lorem ipsum dolor sit amet, cu mnesarchum efficiantur vix, prodesset instructior te sea. No oratio accusata nam, cu magna alterum verterem his, quo te forensibus consetetur. Mei volutpat mediocritatem no, et paulo exerci splendide vel. His vero instructior ad, nam ex maiorum imperdiet.</div>',
                "buttons":{
                    ok:  {
                        label: 'ACEPTO',
                        className: 'btn-success btn-xs'
                    }
                }
               });
            }
        });
    };
    return {
        init: $_build
    };
})(window.jQuery);
(function($) {
    kfk.signUp.init();
})(window.jQuery);