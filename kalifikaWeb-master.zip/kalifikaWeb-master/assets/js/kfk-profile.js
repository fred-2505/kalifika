$.Kalifica.profile = (function($) {
    'use-strict';
    var $change_image = $("#kfk-change-image-user");
    var $image = $("#kfk-image-user");
    var $change_cell = $("#btnCell");
    var $change_mail = $("#btnMail");
    var $verify_cell = $("#verifyNumber");
    var $verify_mail = $("#verifyMail");
    return {
        init: function() {
            $change_image.on("click", function() {
                $image.trigger("click");
            });
            $change_cell.on("click", function() {
                var p = $('<p>').addClass("text-justify m-t-20").text("Verifica tu celular te hemos enviado un SMS");
                var row = $('<div>').addClass('row');
                var divInput = $('<div>').addClass("col-xs-12 col-md-6");
                var divBtn = $('<div>').addClass("col-xs-12 col-md-6");
                var input = $('<input>').addClass("form-control m-t-10");
                var btnValid = $('<button>').addClass('col-xs-12 col-md-6 btn btn-success btn-sm m-t-10').attr({
                    'type': 'button'
                }).text("Verificar");
                var btnRetry = $('<button>').addClass('btn btn-block btn-info').attr({
                    'type': 'button'
                }).text("Si, no te llega el SMS, click aquí");
                divInput.html(input);
                divBtn.html(btnValid);
                row.html(divInput);
                row.append(divBtn);
                $verify_cell.html(p);
                $verify_cell.append(row);
                $verify_cell.append($('<hr>'));
                $verify_cell.append(btnRetry);
            });
            $change_mail.on('click', function() {
                var btn = $('<button>').addClass('btn btn-block btn-info').attr({
                    'type': 'button'
                }).text("Si, no te llega el correo, click aquí");
                $verify_mail.html($('<hr>'));
                $verify_mail.append(btn);
            });
        }
    }
}(window.jQuery));
(function($) {
    'use-strict';
    $.Kalifica.profile.init();
}(window.jQuery));