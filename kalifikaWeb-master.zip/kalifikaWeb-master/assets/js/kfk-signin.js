var kfk = kfk || {};

kfk.signIn = (function ($) {
    'use strict';

    // Initialize Layout
    var $_build = function () {
        
    }

    return {
        init: $_build
    };

})(window.jQuery);


(function ($) {
    kfk.signIn.init();
})(window.jQuery);
