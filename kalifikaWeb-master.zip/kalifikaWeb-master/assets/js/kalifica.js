(function($) {
    'use strict';
    var Kalifica = function() {
        this.VERSION = "1.0.0";
        this.AUTHOR = "INSITE GROUP";
        this.SUPPORT = "soporte@insite.pe";
        this.pageScrollElement = 'html, body';
        this.$body = $('body');
        this.setUserOS();
        this.setUserAgent();
    };
    // Set environment vars
    Kalifica.prototype.setUserOS = function() {
        var OSName = "";
        if (navigator.appVersion.indexOf("Win") != -1) OSName = "kfk-windows";
        if (navigator.appVersion.indexOf("Mac") != -1) OSName = "kfk-mac";
        if (navigator.appVersion.indexOf("X11") != -1) OSName = "kfk-unix";
        if (navigator.appVersion.indexOf("Linux") != -1) OSName = "kfk-linux";
        this.$body.addClass(OSName);
    };
    Kalifica.prototype.setUserAgent = function() {
        if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
            this.$body.addClass('kfk-mobile');
        } else {
            this.$body.addClass('kfk-desktop');
            if (navigator.userAgent.match(/MSIE 9.0/)) {
                this.$body.addClass('ie9');
            }
        }
    };
    Kalifica.prototype.initUnveilPlugin = function() {
        $.fn.unveil && $("img").unveil();
    };
    Kalifica.prototype.initScrollBarPlugin = function(context) {
        $.fn.scrollbar && $('.scrollable', context).scrollbar({
            ignoreOverlay: false
        });
    };
    Kalifica.prototype.bootbox = function() {
        var $chose_bank = $(".kfk-login-bootbox");
        var body = $('<div>').addClass('').css({
            "opacity": "1",
            "background": "transparent"
        });
        var div_content = $('<div>').addClass('text-center');
        var img = $('<img>').attr({
            "data-src": "assets/images/logo.png",
            "data-src-retina": "assets/images/logo.png",
            "src": "assets/images/logo.png"
        });
        var form = $('<form>').attr({
            "action": "",
            "id": "kfk-form1",
            "method": "POST",
            "role": "form"
        });
        var div_input1 = $('<div>').addClass('form-group');
        var input_1 = $('<input>').addClass('form-control text-center').attr({
            "placeholder": "Ingrese su DNI",
            "type": "text"
        });
        var div_input2 = $('<div>').addClass('form-group');
        var input_2 = $('<input>').addClass('form-control text-center').attr({
            "placeholder": "Ingrese su password",
            "type": "password"
        });
        var div_input3 = $('<div>').addClass('checkbox text-left');
        var input_3 = $('<input>').attr({
            "id": "kfk-checkbox",
            "type": "checkbox"
        });
        var label_3 = $('<label>').text("Recordar mi correo").attr("for", "kfk-checkbox");
        var a_submit = $('<a>').addClass('btn btn-primary btn-block text-center').attr({
            "href": "mikalifika.php",
            "type": "submit"
        }).text("Ingresar");
        var div_cuenta1 = $('<div>').html('¿No tienes una cuenta?<br/>').addClass('text-center m-t-10');
        var a_cuenta1 = $('<a>').addClass('link text-center').attr("href", "signup.php").text("Regístrate ahora, es gratis");
        var div_cuenta2 = $('<div>').html("¿Tienes problemas para ingresar?<br/>").addClass('text-center');
        var a_cuenta2 = $('<a>').addClass('page-scroll text-center').attr("href", "#kfk-section-contactos").text("Contáctenos aquí");
        div_input1.html(input_1);
        div_input2.html(input_2);
        div_input3.html(input_3);
        div_input3.append(label_3);
        div_input3.append(a_submit);
        div_content.html(img);
        form.html(div_input1);
        form.append(div_input2);
        form.append(div_input3);
        form.append(a_submit);
        form.append($('<hr>').addClass('m-b-0'));
        div_cuenta1.append(a_cuenta1);
        form.append(div_cuenta1);
        form.append($('<hr>').addClass('m-b-10 m-t-10'));
        div_cuenta2.append(a_cuenta2);
        form.append(div_cuenta2);
        body.html(div_content);
        body.append($('<br>'));
        body.append(form);
        $chose_bank.on('click', function() {
            var dialog = bootbox.dialog({
                message: body
            })
            dialog.init(function() {
                a_cuenta2.on('click', function() {
                    dialog.modal('hide');
                });
                dialog.css({
                    'top': '45%',
                    'margin-top': function() {
                        return -(dialog.height() / 2);
                    }
                });
                $('.modal-body').css({
                    'padding': '30px'
                })
            });
        });
    };
    Kalifica.prototype.getData = function(type) {
        return [{
            "mes": "Nov2015",
            "value": 350
        }, {
            "mes": "Dic2015",
            "value": 410
        }, {
            "mes": "Ene2016",
            "value": 350
        }, {
            "mes": "Feb2016",
            "value": 500
        }, {
            "mes": "Mar2016",
            "value": 250
        }, {
            "mes": "Abr2016",
            "value": 420
        }, {
            "mes": "May2016",
            "value": 400
        }, {
            "mes": "Jun2016",
            "value": 380
        }, {
            "mes": "Jul2016",
            "value": 320
        }, {
            "mes": "Ago2016",
            "value": 380
        }, {
            "mes": "Set2016",
            "value": 450
        }, {
            "mes": "Oct2016",
            "value": 500
        }, {
            "mes": "Nov2016",
            "value": 420
        }, {
            "mes": "Dic2016",
            "value": 400
        }];
    };
    Kalifica.prototype.createChart = function(data, title, max, min) { // SERIAL CHART
        var chart = new AmCharts.AmSerialChart();
        chart.dataProvider = data;
        chart.marginLeft = 10;
        chart.categoryField = "mes";
        //CATEGORY
        var categoryAxis = chart.categoryAxis;
        categoryAxis.gridThickness = 0;
        // VALUE
        var valueAxis = new AmCharts.ValueAxis();
        valueAxis.minimum = min;
        valueAxis.maximum = max;
        valueAxis.stackType = "regular";
        valueAxis.gridAlpha = 0;
        valueAxis.autoGridCount = false;
        valueAxis.gridCount = 50;
        valueAxis.labelFrequency = 10;
        chart.addValueAxis(valueAxis);
        // GRAPH
        var graph = new AmCharts.AmGraph();
        graph.type = "smoothedLine"; // this line makes the graph smoothed line.
        graph.lineColor = "#57ce79";
        graph.negativeLineColor = "#637bb6"; // this line makes the graph to change color when it drops below 0
        graph.bullet = "round";
        graph.bulletSize = 8;
        graph.bulletBorderColor = "#FFFFFF";
        graph.bulletBorderAlpha = 1;
        graph.bulletBorderThickness = 2;
        graph.lineThickness = 2;
        graph.valueField = "value";
        graph.balloonText = "[[category]]<br><b><span style='font-size:14px;'>[[value]]</span></b>";
        chart.addGraph(graph);
        // CURSOR
        var chartCursor = new AmCharts.ChartCursor();
        chartCursor.cursorAlpha = 0;
        chartCursor.cursorPosition = "mouse";
        chartCursor.categoryBalloonEnabled = false;
        chart.addChartCursor(chartCursor);
        // BALOON
        var balloon = new AmCharts.AmBalloon();
        balloon.borderAlpha = 0;
        balloon.borderThickness = 1;
        balloon.color = "#5D5D5D";
        chart.balloon = balloon;
        //TITLE
        chart.addTitle(title, 15, "#5D5D5D", 1)
        //Scrollbar
        return chart;
    };
    Kalifica.prototype.createBar = function(idChart, score, max, min) {
        var char = AmCharts.makeChart(idChart, {
            "type": "serial",
            "rotate": true,
            "theme": "light",
            "autoMargins": true,
            "dataProvider": [{
                "category": "",
                "value": score,
                "full": max
            }],
            "valueAxes": [{
                "minimum": min,
                "maximum": max,
                "stackType": "regular",
                "gridAlpha": 0,
                "autoGridCount": false,
                "gridCount": 50,
                "labelFrequency": 10
            }],
            "chartCursor": {
                "oneBalloonOnly": true,
                "cursorColor": "TRANSPARENT"
            },
            "balloon": {
                "drop": true,
                "horizontalPadding": 5,
                "pointerOrientation": "down",
                "adjustBorderColor": true,
                "color": "#000",
                "cornerRadius": 5,
                "borderAlpha": 0,
                "fillColor": "TRANSPARENT"
            },
            "categoryAxis": {
                "axisColor": "TRANSPARENT",
                "axisThickness": 0
            },
            "startDuration": 1,
            "graphs": [{
                "valueField": "full",
                "showBalloon": false,
                "type": "column",
                "lineAlpha": 0,
                "fillAlphas": 0.8,
                "fillColors": ["#fb2316", "#f6d32b", "#19d228"],
                "gradientOrientation": "horizontal",
            }, {
                "clustered": false,
                "columnWidth": 1,
                "lineColor": "#3498DB",
                "lineThickness": 7,
                "stackable": false,
                "type": "step",
                "valueField": "value"
            }],
            "columnWidth": 1,
            "categoryField": "category",
            "categoryAxis": {
                "gridAlpha": 0,
                "position": "left"
            }
        });
    };
    Kalifica.prototype.init = function() {
        this.initScrollBarPlugin();
        this.initUnveilPlugin();
        this.bootbox();
        $('#kfk-dialog-bootbox').on('click', function() {
            var deuda_min = $(this).data('deuda-min');
            var score_min = $(this).data('score-min');
            var deuda_max = $(this).data('deuda-max');
            var score_max = $(this).data('score-max');
            var content = $('<div>').addClass('text-center');
            var h3 = $('<h3>').text('Historial').addClass('text-primary')
            var small = $('<small>').addClass('text-primary').html('volver<i class="fa fa-arrow-right"></i>');
            var close = $('<a>').append(small).addClass('close-deuda cursor pull-right');
            var div = $('<div>').addClass('row');
            var divc1 = $('<div>').addClass('col-xs-12 col-sm-6');
            var divc2 = $('<div>').addClass('col-xs-12 col-sm-6');
            var dcha1 = $('<div>').attr('id', 'chartdiv1').css('height', '300px');
            var dcha2 = $('<div>').attr('id', 'chartdiv2').css('height', '300px');
            divc1.append(dcha1);
            divc2.append(dcha2);
            div.append(divc1);
            div.append(divc2);
            content.append(close);
            content.append(h3);
            content.append(div);
            content.append($('<br>'));
            var dialog = bootbox.dialog({
                closeButton: false,
                size: 'large',
                message: content,
                className: 'claseHistorial'
            });
            dialog.css({
                'top': '40%',
                'margin-top': function() {
                    return -(dialog.height() / 2);
                }
            });
            dialog.init(function() {
                var chart1 = $.Kalifica.createChart($.Kalifica.getData(1), "Score", score_max, score_min);
                var chart2 = $.Kalifica.createChart($.Kalifica.getData(2), "Deuda", deuda_max, deuda_min);
                chart1.write("chartdiv1");
                chart2.write("chartdiv2");
                $('.close-deuda').on('click', function() {
                    dialog.modal('hide');
                });
            });
        });
    }
    $.Kalifica = new Kalifica();
    $.Kalifica.Constructor = Kalifica;
})(window.jQuery);
(function($) {
    'use strict';
    $.Kalifica.init();
})(window.jQuery);