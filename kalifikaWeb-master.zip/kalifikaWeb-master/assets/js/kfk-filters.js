$.Kalifica.filters = (function($) {
    'use strict';
    var $chose_bank = $(".kfk-dialog");
    var $grafic_score = $(".kfk-score-bar");
    return {
        init: function() {
            $('.help').tooltip({
                'template': '<div class="tooltip kfk-tooltip-help" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
            });
            var viewportWidth = $(window).width();
            if (viewportWidth < 480) {
                $(".accordion-toggle").addClass("collapsed");
                $("#filter").removeClass("in");
            } 
            $('.kfk-button').on('click', function() {
                if ($(this).hasClass('btn-default')) {
                    $('.kfk-button').addClass('btn-default');
                    $('.kfk-button').removeClass('btn-primary');
                    $(this).removeClass('btn-default');
                    $(this).addClass('btn-primary');
                    $('.kfk-button').css('background-color', '#FFF');
                    $(this).css('background-color', '#37bb5d');
                } else {
                    $('.kfk-button').removeClass('btn-primary');
                    $('.kfk-button').css('background-color', '#FFF');
                    $(this).addClass('btn-default');
                }
            });
            $('.accordion-toggle').on('click', function() {
                var id = $(this).data('id');
                $('#condice_' + id).toggleClass('open');
                if ($('#condice_' + id).hasClass("open")) {
                    $('#condice_' + id).text("No ver condiciones");
                    $('#condice_' + id + '_xs').text("No ver condiciones");
                } else {
                    $('#condice_' + id).text("Ver condiciones");
                    $('#condice_' + id + '_xs').text("Ver condiciones");
                }
            });
            $chose_bank.on('click', function() {
                var id = $(this).data("id");
                //el id que se envia a través de la data-id del button
                console.log(id)
                var type = $(this).data("type");
                var dialog = bootbox.dialog({
                    message: "<p class='text-center'><br/><br/>Tu solicitud de " + type + " ha sido enviada correctamente. <br> La entidad financiera pronto se pondrá en contacto contigo.<br/><br/></p>",
                    buttons: {}
                })
                dialog.css({
                    'top': '50%',
                    'margin-top': function() {
                        return -(dialog.height() / 2);
                    }
                });
            });
        }
    };
}(window.jQuery));
(function($) {
    'use strict';
    $.Kalifica.filters.init();
})(window.jQuery);