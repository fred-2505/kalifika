$.Kalifica.index = (function ($) {

    'use-strict';


    var $step_controller = $("#kfk-steps");
    var $step_count = $("#kfk-step-count");
    var $steps = $(".kfk-step .fa-index");
    var step_init = "#kfk-step-1";

    var build = function () {
        generate_steps();
//        animation();
        animation(step_init);
        $(step_init).click();
        setInterval(function () {
            animation(step_init);
            $(step_init).click();
        }, $step_controller.attr("data-loop"));
        stop_video();
        setTimeout(function () {
            $(".kfk-media-app-left").addClass("move-left");
            $(".kfk-media-app-right").addClass("move-right");
        }, 1000);
    };

    var step = function (num, col) {
        var tindex = (num + 1);

        if ((num * col) === 12) {
            tindex = 1;
        }

        var col = $("<div>").addClass("col-xs-" + col);
        var feacture = $("<div>").addClass("feature kfk-step");
        var num = $('<i class="fa fa-index font-step">').attr({"id": "kfk-step-" + num, "data-num": tindex, "data-tabindex": "kfk-step-" + tindex}).html(num);

        feacture.append(num);
        col.append(feacture);
//        animation(num);

        return col;

    };

    var reset_active = function () {
        $(".kfk-step .fa-index").removeClass("active");
        $(".kfk-step-detail").addClass("hidden");
    };

    var animation = function (step) {
        $(step).on("click", function () {
            reset_active();
            var tabindex = $(this).attr("data-tabindex");
            if ($(this).attr("data-num") == 2) {
                setTimeout(function () {
                    $(".kfk-media-app-left").addClass("move-left");
                    $(".kfk-media-app-right").addClass("move-right");
                }, 500);
            } else {
                $(".kfk-media-app-left").removeClass("move-left");
                $(".kfk-media-app-right").removeClass("move-right");
            }
            $("#" + this.id + "-detail").removeClass("hidden");
            $(this).addClass("active");
            step_init = "#" + tabindex;
        });

    };

    var validate_count_steps = function (total) {
        if ((12 % total) === 0) {
            return true;
        }
        return false;
    }

    var generate_steps = function () {
        var total = $step_controller.data("steps");
        if (!validate_count_steps(total)) {
            console.error("La cantidad de steps para generar no está permitido");
            return false;
        }

        var steps = 12 / total;

        var row = $("<div>").add("row");
        $step_controller.html("");

        for (var i = 1; i <= total; i++) {
            $step_controller.append(step(i, steps));
        }

//        $step_controller.html(row);
        $step_count.html(total);

    }

    var stop_video = function () {

        $('.dialog__close').on('click', function () {
            var emebed = $("#" + $(this).attr("data-embed"));
            var src = emebed.find("iframe").attr("src");
            emebed.empty();
            emebed.html('<iframe class="kfk-dialog-video" width="560" height="315" src="' + src + '" frameborder="0" allowfullscreen></iframe>')
        });
    }


    return {
        init: build
    };
}(window.jQuery));

(function ($) {

    'use-strict';

    $.Kalifica.index.init();

}(window.jQuery));
