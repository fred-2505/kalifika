$.Kalifica.person = (function($) {
    'use strict';
    return {
        init: function() {
            $('.help').tooltip({
                'template': '<div class="tooltip kfk-tooltip-help" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
            });
            var $grafic_score = $("#chartDiv");
            if ($grafic_score) {
                var max = $('#kfk-graphic-score').data('score-max');
                var min = $('#kfk-graphic-score').data('score-min');
                var chart = $.Kalifica.createChart($.Kalifica.getData(1), "Score", max, min);
                chart.write("kfk-graphic-score");
                var idChart = $grafic_score.attr("id");
                var score = $grafic_score.data("score");
                var max_bar = $grafic_score.data('max');
                var min_bar = $grafic_score.data('min');
                $.Kalifica.createBar(idChart, score, max_bar, min_bar);
            }
        }
    };
}(window.jQuery));
(function($) {
    'use strict';
    $.Kalifica.person.init();
})(window.jQuery);