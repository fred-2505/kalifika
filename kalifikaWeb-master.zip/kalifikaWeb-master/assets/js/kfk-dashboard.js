$.Kalifica.dashboard = (function($) {
    'use strict';
    var $btn_category_score = $(".kfk-category-score");
    var $content_score = $(".kfk-score");
    var $grafic_score = $(".kfk-score-bar");
    var graph;
    var chartData;
    return {
        init: function() {
            $btn_category_score.on("click", function() {
                $content_score.attr("class", "kfk-score kfk-score-" + $(this).data("category")).find(".kfk-score-number").html($(this).data("score"));
            });
            var idChart = $grafic_score.attr("id");
            var score = $grafic_score.data("score");
            var max = $grafic_score.data('max');
            var min = $grafic_score.data('min');
            $.Kalifica.createBar(idChart, score, max,min);
        }
    };
}(window.jQuery));
(function($) {
    'use strict';
    $.Kalifica.dashboard.init();
})(window.jQuery);